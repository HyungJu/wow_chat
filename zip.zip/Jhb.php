
  <head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="1;url=./Jhb.php">


	  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.4/css/bootstrap.min.css" integrity="2hfp1SzUoho7/TsGGGDaFdsuuDL0LX2hnUp6VkX3CUQ2K4K+xjboZdsXyp4oUHZj" crossorigin="anonymous">
  </head>

<body>
	
<div class="card card-block" style="width: 18rem;">
  <h3 class="card-title"><strong><?php 
	  $fpread = fopen("./jhb.txt","r");
$msgf = fread($fpread, filesize("./jhb.txt"));
	  
fclose($fpread); 
	  $con = explode("<<",$msgf);
	  echo $con[0];
	  ?></strong></h3>
  <p class="card-text">By <?php 
	  $fpread = fopen("./jhb.txt","r");
$msgf = fread($fpread, filesize("./jhb.txt"));
	  
fclose($fpread); 
	  $con = explode("<<",$msgf);
	  echo $con[1]; ?></p>
 
</div>



	
	
	</body>