

<h1>
	I am Genious 사 에서 운영하는 보안 챗입니다. <br> 사용자의 보안과 <del>귀차니즘</del>으로 한번에 1 문자만 전달됩니다.
</h1>

<form action="refresh.php" method="post">
입력 : <input type="text" name="msg0" >

	
</form>

<?php
$msg = $_POST['msg0'];
$fp = fopen("./jhb.txt","w");
fwrite($fp, $msg."  <<  toast")

?>