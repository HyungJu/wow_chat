<form action="index.php" method="post">
<input name="msg0">
</form>

<?php
$msg = $_POST['msg0'];
echo $msg;
 ?>